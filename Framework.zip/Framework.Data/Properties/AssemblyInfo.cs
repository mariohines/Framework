﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyProduct("Framework.Data")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("29f76c10-3c20-4bcc-bfb1-04b7b4537421")]