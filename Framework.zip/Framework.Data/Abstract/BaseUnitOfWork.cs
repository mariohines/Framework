﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="UnitOfWork.cs" >
// </copyright>
// <summary>
//   Defines the UnitOfWork type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Transactions;
using Framework.Data.Enumerations;
using Framework.Data.Exceptions;
using Framework.Data.Interfaces;
using Framework.IoC;
using Ninject;

namespace Framework.Data.Abstract
{
	/// <summary>
	/// Defines the UnitOfWork type.
	/// </summary>
	public class BaseUnitOfWork
		: IUnitOfWork
	{
		/// <summary>
		/// Gets the Unit of Work context.
		/// </summary>
		private readonly IObjectContext _objectContext;

		/// <summary>
		/// Gets the TransactionScope of this Unit of Work.
		/// </summary>
		private readonly TransactionScope _transactionScope;

		/// <summary>
		/// Initializes a new instance of the <see cref="BaseUnitOfWork"/> class. 
		/// </summary>
		/// <param name="objectContext">Data context to use in UoW</param>
		public BaseUnitOfWork(IObjectContext objectContext) {
			// set Default behavior.
			DefaultOptions = UnitOfWorkOptions.AutoCommit;
			Status = UnitOfWorkStatus.Active;

			_objectContext = objectContext;

			// Push this UoW into the stack.
			_objectContext.UnitOfWorkStack.Push(this);

			// create Transaction scope..
			_transactionScope = new TransactionScope();
		}

		/// <summary>
		/// Finalizes an instance of the <see cref="BaseUnitOfWork"/> class. 
		/// </summary>
		~BaseUnitOfWork() {
			Dispose(false);
		}

		/// <summary>
		/// Gets a value indicating whether the Unit of Work is at the Top Level.
		/// </summary>
		public bool IsTopLevel {
			get { return _objectContext.UnitOfWorkCount == 1; }
		}

		/// <summary>
		/// Gets or sets the Default behavior for Commits and Rollbacks for this Unit Of Work.
		/// </summary>
		public UnitOfWorkOptions DefaultOptions { get; set; }

		/// <summary>
		/// Gets or sets the Status of this Unit Of Work.
		/// </summary>
		public UnitOfWorkStatus Status { get; set; }

		/// <summary>
		/// Gets or sets the Audit information to use during the SaveChanges().
		/// </summary>
		public AuditInfo AuditInfo { get; set; }

		/// <summary>
		/// Return a new instance of the UnitOfWork class with the default behavior.
		/// </summary>
		/// <returns>A new instance of the UnitOfWork class.</returns>
		public static IUnitOfWork GetUnitOfWork() {
			return GetUnitOfWork(UnitOfWorkOptions.DefaultOptions);
		}

		/// <summary>
		/// Return the current instance of the Unit of Work class or create a new instance of the UnitOfWork class with the default behavior.
		/// </summary>
		/// <param name="createNew">A value indicating whether to create a New UoW or return the existing UoW</param>
		/// <returns>An instance of the UnitOfWork class.</returns>
		public static IUnitOfWork GetUnitOfWork(bool createNew) {
			if (createNew) {
				return GetUnitOfWork(UnitOfWorkOptions.DefaultOptions);
			}

			// Return existing UoW if there is one..
			// Get instance to ObjectContext..
			var context = IocKernel.Instance.TryGet<IObjectContext>();
			if (context.UnitOfWorkCount == 0) {
				throw new InvalidUnitOfWorkException();
			}

			// Get current UnitOfWork.
			return context.UnitOfWorkStack.Peek();
		}

		/// <summary>
		/// Return a new instance of the Unit of Work class with the specified behavior.
		/// </summary>
		/// <param name="defaultOption">The default Behavior for the new unitOfWork object.</param>
		/// <returns>A new instance of the UnitOfWork class with the Default behavior set.</returns>
		public static IUnitOfWork GetUnitOfWork(UnitOfWorkOptions defaultOption) {
			var newUoW = IocKernel.Instance.TryGet<IUnitOfWork>();
			newUoW.DefaultOptions = defaultOption;
			return newUoW;
		}

		/// <summary>
		/// Execute unitof work code block inside a unit of work.
		/// </summary>
		/// <param name="codeBlock">code block to execute inside as a unit of work.</param>
		public static void Do(Action<IUnitOfWork> codeBlock) {
			Do(UnitOfWorkOptions.DefaultOptions, codeBlock);
		}

		/// <summary>
		/// Execute code block inside a unit of work.
		/// </summary>
		/// <param name="defaultOption">The default Behavior for the new unitOfWork object.</param>
		/// <param name="codeBlock">code block to execute inside as a unit of work.</param>
		public static void Do(UnitOfWorkOptions defaultOption, Action<IUnitOfWork> codeBlock) {
			Do(defaultOption, null, codeBlock);
		}

		/// <summary>
		/// Execute code block inside a unit of work.
		/// </summary>
		/// <param name="defaultOption">The default Behavior for the new unitOfWork object.</param>
		/// <param name="auditInfo">AuditInfo class to use during save operation.</param>
		/// <param name="codeBlock">code block to execute inside as a unit of work.</param>
		public static void Do(UnitOfWorkOptions defaultOption, AuditInfo auditInfo, Action<IUnitOfWork> codeBlock) {
			var unitOfWork = OnEntryAdvice(defaultOption);
			unitOfWork.AuditInfo = auditInfo;
			try {
				codeBlock(unitOfWork);
				OnSuccessAdvice(unitOfWork);
			}
			catch {
				OnExceptionAdvice(unitOfWork);
				throw;
			}
			finally {
				OnExitAdvice(unitOfWork);
			}
		}

		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		public void Dispose() {
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Commit all changes to repository.
		/// </summary>
		/// <returns>A value indicating the result of the commit operation.</returns>
		public int Commit() {
			var result = 0;

			if (IsTopLevel) {
				// save changes.
				result = _objectContext.SaveChanges();
			}

			_transactionScope.Complete();

			Status = UnitOfWorkStatus.Committed;
			return result;
		}

		/// <summary>
		/// Rollback changes not already commited.
		/// </summary>
		public void RollbackChanges() {
			// Rollback changes.
			Status = UnitOfWorkStatus.RolledBack;
		}

		#region Internal Methods for UnitOfWorkAttribute

		/// <summary>
		/// This is an Internal method used by UnitOfWork postsharp Aspect.
		/// Create a new instance of the UnitOfWork class with the specified behavior.
		/// </summary>
		/// <param name="defaultOption">behaviour for new UnitOfWork.</param>
		/// <returns>Instance of new Unit Of Work</returns>
		internal static IUnitOfWork OnEntryAdvice(UnitOfWorkOptions defaultOption) {
			return GetUnitOfWork(defaultOption);
		}

		/// <summary>
		/// This is an Internal method used by the UnitOfWork postsharp Aspect.
		/// Perform Auto-Commit logic.
		/// </summary>
		/// <param name="unitOfWork">Instance to UnitOfWork</param>
		internal static void OnSuccessAdvice(IUnitOfWork unitOfWork) {
			if (unitOfWork != null && unitOfWork.Status == UnitOfWorkStatus.Active &&
			    unitOfWork.DefaultOptions.HasFlag(UnitOfWorkOptions.AutoCommit)) {
				// Commit.
				unitOfWork.Commit();
			}
		}

		/// <summary>
		/// This is an Internal method used by the UnitOfWork postsharp Aspect.
		/// Dispose of UnitOfWork class.
		/// </summary>
		/// <param name="unitOfWork">Instance to UnitOfWork</param>
		internal static void OnExitAdvice(IUnitOfWork unitOfWork) {
			if (unitOfWork != null) {
				unitOfWork.Dispose();
			}
		}

		/// <summary>
		/// This is an Internal method used by the UnitOfWork postsharp Aspect.
		/// Rollback UnitOfWork.
		/// </summary>
		/// <param name="unitOfWork">Instance to UnitOfWork</param>
		internal static void OnExceptionAdvice(IUnitOfWork unitOfWork) {
			if (unitOfWork != null && unitOfWork.Status == UnitOfWorkStatus.Active) {
				// then Roll back.
				unitOfWork.RollbackChanges();
			}
		}

		#endregion

		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		/// <param name="disposing">Value indicating whether object is being disposed.</param>
		protected virtual void Dispose(bool disposing) {
			if (Status != UnitOfWorkStatus.Disposed) {
				if (disposing) {
					// Dispose transaction scope.
					_transactionScope.Dispose();

					// Decrease UnitOfWork counter.
					_objectContext.UnitOfWorkStack.Pop();
				}
			}

			Status = UnitOfWorkStatus.Disposed;
		}
	}
}