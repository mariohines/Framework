﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Framework.Data.Interfaces;
using LinqKit;

namespace Framework.Data.Abstract
{
	/// <summary></summary>
	/// <typeparam name="TEntity"></typeparam>
	public abstract class BaseDbRepository<TEntity> : IDbRepository<TEntity>
		where TEntity : class, new()
	{
		/// <summary>Gets the current object inherited from IDbContext.</summary>
		protected IDbContext Context { get; private set; }

		/// <summary>Gets the current IDbSet of type <typeparamref name="TEntity"/>.</summary>
		protected IDbSet<TEntity> ItemSet { get; private set; }

		#region Constructors
		protected BaseDbRepository (IDbContext dbContext) {
			Context = dbContext;
			ItemSet = dbContext.CreateDbSet<TEntity>();
		}

		~BaseDbRepository() {
			Dispose();
		}
		#endregion End Constructors

		#region Implementation of IDisposable
		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		/// <filterpriority>2</filterpriority>
		public void Dispose() {
			if (Context != null) {
				SaveChanges();
				Context.Dispose();
			}
			GC.SuppressFinalize(this);
		}
		#endregion

		#region Implementation of IDbRepository<T>
		/// <summary>Generic method to 'Get' a single object based on the passed in IQuery parameters.</summary>
		/// <param name="parameters">An array of expressions to query by.</param>
		/// <returns>A single object of type T.</returns>
		[DebuggerNonUserCode]
		public virtual TEntity Get (params Expression<Func<TEntity, bool>>[] parameters) {
			var results = parameters.Aggregate(ItemSet.AsExpandable(), (current, expression) => current.Where(expression));
			return results.SingleOrDefault();
		}

		/// <summary>Generic method to 'Get' a collection of T.</summary>
		/// <param name="parameters">An array of expressions to query by.</param>
		/// <returns>A collection of type T.</returns>
		[DebuggerNonUserCode]
		public virtual IEnumerable<TEntity> GetEntities (params Expression<Func<TEntity, bool>>[] parameters) {
			var results = parameters.Aggregate(ItemSet.AsExpandable(), (current, expression) => current.Where(expression));
			return results.ToList();
		}

		/// <summary>Generic method to 'Get' a collection of T.</summary>
		/// <param name="parameters">An array of expressions to query by.</param>
		/// <param name="maxRows">The max number of rows to take.</param>
		/// <returns>A collection of type T.</returns>
		[DebuggerNonUserCode]
		public virtual IEnumerable<TEntity> GetEntities (int maxRows, params Expression<Func<TEntity, bool>>[] parameters) {
			var results = parameters.Aggregate(ItemSet.AsExpandable(), (current, expression) => current.Where(expression));
			return results.Take(maxRows).ToList();
		}

		/// <summary></summary>
		/// <param name="parameters">An array of expressions to query by.</param>
		/// <returns></returns>
		[DebuggerNonUserCode]
		public virtual long GetEntitiesCount (params Expression<Func<TEntity, bool>>[] parameters) {
			var results = parameters.Aggregate(ItemSet.AsExpandable(), (current, expression) => current.Where(expression));
			return results.LongCount();
		}

		/// <summary>Method to add an entity to the DbContext.</summary>
		/// <param name="entity">The entity to add.</param>
		[DebuggerNonUserCode]
		public virtual void Add(TEntity entity) {
			ItemSet.Add(entity);
		}

		/// <summary>Generic method to add objects to the object context.</summary>
		/// <param name="entities">An array of T objects.</param>
		[DebuggerNonUserCode]
		public virtual void Add(params TEntity[] entities) {
			entities.ForEach(Add);
		}

		/// <summary>Method to update the specified entity.</summary>
		/// <param name="entity">The entity to update.</param>
		[DebuggerNonUserCode]
		public virtual void Update (TEntity entity) {
			Context.SetChanges(entity);
		}

		/// <summary>Method to update the specified entities.</summary>
		/// <param name="entities">The entities to update.</param>
		[DebuggerNonUserCode]
		public virtual void Update (params TEntity[] entities) {
			entities.ForEach(Update);
		}

		/// <summary>Method to save the changes to the ObjectContext.</summary>
		/// <returns>An integer value from the DbContext.</returns>
		[DebuggerNonUserCode]
		public virtual int SaveChanges () {
			return Context.SaveChanges();
		}

		/// <summary>Method to attach an object to the DbContext.</summary>
		/// <param name="entity">The specified entity to attach.</param>
		/// <returns>The attached object of the specified type.</returns>
		[DebuggerNonUserCode]
		public virtual TEntity Attach (TEntity entity) {
			return Context.Attach(entity);
		}

		/// <summary>Method to remove an object from the DbContext.</summary>
		/// <param name="entity">The entity to remove.</param>
		[DebuggerNonUserCode]
		public virtual void Remove (TEntity entity) {
			ItemSet.Remove(entity);
		}

		/// <summary>Method to remove the specified objects from the DbContext.</summary>
		/// <param name="entities">The specified objects to remove.</param>
		[DebuggerNonUserCode]
		public virtual void Remove (params TEntity[] entities) {
			entities.ForEach(Remove);
		}

		/// <summary>Method to execute a stored procedure.</summary>
		/// <param name="procedureName">The name of the procedure.</param>
		/// <param name="parameters">The parameter array.</param>
		[DebuggerNonUserCode]
		public virtual void ExecuteProcedure (string procedureName, Dictionary<string, object> parameters) {
			if (string.IsNullOrWhiteSpace(procedureName)) {
				throw new ArgumentNullException("procedureName");
			}
			var builder = new StringBuilder();
			builder.AppendFormat("{0} ", procedureName.Replace(" ", string.Empty));
			builder.Append(string.Join(", ", parameters.Keys));
			Context.ExecuteProcedure(builder.ToString(), parameters.Values.ToArray());
		}

		#endregion
	}
}
