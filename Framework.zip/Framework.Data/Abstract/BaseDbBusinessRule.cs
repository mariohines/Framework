﻿using System;
using System.Diagnostics;
using Framework.Data.Interfaces;
using Framework.Extensions;

namespace Framework.Data.Abstract
{
	/// <summary>An abstract base class for implementation of IDbBusinessRule.</summary>
	/// <typeparam name="TRepository">An object that inherits from IDbRepository.</typeparam>
	/// <typeparam name="TEntity">An object that is usually a POCO class.</typeparam>
	public abstract class BaseDbBusinessRule<TRepository, TEntity> : IDbBusinessRule<TEntity>
		where TEntity : class, new()
		where TRepository : IDbRepository<TEntity>
	{
		/// <summary>Gets the protected repository based on IDbRepository.</summary>
		protected TRepository Repository { get; private set; }

		protected BaseDbBusinessRule (TRepository repository)
			: this(repository, null) { }

		protected BaseDbBusinessRule(TRepository repository, IDbBusinessRule<TEntity> nextRule ) {
			Repository = repository;
			NextRule = nextRule;
		}

		#region Implementation of IDbBusinessRule<TEntity>

		/// <summary>The next IDbBusinessRule of type <typeparamref name="TEntity"/> to process.</summary>
		public IDbBusinessRule<TEntity> NextRule { get; private set; }

		/// <summary>Method to process a rule.</summary>
		/// <param name="action">The passed in action to process.</param>
		/// <returns>An IDbBusiness rule of type <typeparamref name="TEntity"/>.</returns>
		[DebuggerNonUserCode]
		public virtual IDbBusinessRule<TEntity> ProcessRule(Action action) {
			if (!action.IsNull()) {
				action();
			}
			return NextRule.IsNull() ? this : NextRule;
		}

		/// <summary>Method to process a rule.</summary>
		/// <param name="action">The passed in action on type <typeparamref name="TEntity"/> to process.</param>
		/// <param name="entity">The entity to process.</param>
		/// <returns>An IDbBusiness rule of type <typeparamref name="TEntity"/>.</returns>
		[DebuggerNonUserCode]
		public virtual IDbBusinessRule<TEntity> ProcessRule(Action<TEntity> action, TEntity entity) {
			if (!action.IsNull()) {
				action(entity);
			}
			return NextRule.IsNull() ? this : NextRule;
		}

		/// <summary>Method to process a rule.</summary>
		/// <param name="func">The passed in function to process.</param>
		/// <returns>An IDbBusiness rule of type <typeparamref name="TEntity"/>.</returns>
		[DebuggerNonUserCode]
		public virtual IDbBusinessRule<TEntity> ProcessRule(Func<object> func) {
			var result = default(object);
			if (!func.IsNull()) {
				result = func();
			}
			return result is IDbBusinessRule<TEntity>
			       	? result as IDbBusinessRule<TEntity>
			       	: NextRule.IsNull()
			       	  	? this
			       	  	: NextRule;
		}

		/// <summary>Method to process a rule.</summary>
		/// <param name="func">The passed in function of type <typeparamref name="TEntity"/> to process.</param>
		/// <param name="entity">The entity to process.</param>
		/// <returns>An IDbBusiness rule of type <typeparamref name="TEntity"/>.</returns>
		[DebuggerNonUserCode]
		public virtual IDbBusinessRule<TEntity> ProcessRule(Func<TEntity, object> func, TEntity entity) {
			var result = default(object);
			if (!func.IsNull()) {
				result = func(entity);
			}
			return result is IDbBusinessRule<TEntity>
			       	? result as IDbBusinessRule<TEntity>
			       	: NextRule.IsNull()
			       	  	? this
			       	  	: NextRule;
		}

		/// <summary>Method to complete processing of rules. [Abstract in base classes]</summary>
		public abstract void CompleteProcessing();

		#endregion

		#region Implementation of IDisposable

		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		/// <filterpriority>2</filterpriority>
		[DebuggerNonUserCode]
		public virtual void Dispose() {
			NextRule = null;
			GC.Collect();
		}

		#endregion
	}
}