﻿using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Diagnostics;
using System.Linq;
using Framework.Data.Enumerations;
using Framework.Data.Exceptions;
using Framework.Data.Extensions;
using Framework.Data.Interfaces;
using Framework.Data.Specifications;
using LinqKit;

namespace Framework.Data.Abstract
{
	public abstract class BaseObjectRepositoryEx<TObjectContext, TEntity> : IObjectRepository<TEntity> 
		where TObjectContext : class, IObjectContext
		where TEntity : class, IObjectWithChangeTracker, new()
	{
		/// <summary>Gets the current object inherited from <typeparamref name="TObjectContext"/>.</summary>
		protected TObjectContext Context { get; private set; }

		/// <summary>
		/// 
		/// </summary>
		protected virtual IObjectSet<TEntity> ItemSet { get; private set; } 

		protected BaseObjectRepositoryEx(TObjectContext context) {
			if (context == null) {
				throw new ArgumentNullException("context", "The context cannot be null");
			}

			Context = context;
			Context.RepositoryCount++;
			ItemSet = context.CreateObjectSet<TEntity>();
		}

		~BaseObjectRepositoryEx() {
			Dispose();
		}

		#region Properties

		/// <summary>
		/// Gets or sets the Status of this Unit Of Work.
		/// </summary>
		private RepositoryStatus Status { get; set; }

		#endregion

		#region Methods

		/// <summary>
		/// Add item to repository.
		/// </summary>
		/// <param name="item">Item to add to repository.</param>
		[DebuggerNonUserCode]
		public virtual void Add (TEntity item) {
			// check arguments
			if (item == null) {
				throw new ArgumentNullException("item", "'item' argument is null.");
			}

			// check Unit of work.
			if (Context.UnitOfWorkCount <= 0) {
				throw new InvalidUnitOfWorkException();
			}

			// add object to IObjectSet for this type
			if (ItemSet is ObjectSet<TEntity>) {
				//((ObjectSet<TEntity>)ItemSet).ApplyChanges(item);  
			} else {
				ItemSet.AddObject(item);
			}
		}

		/// <summary>
		/// Delete an item from repository.
		/// </summary>
		/// <param name="item">Item to delete.</param>
		[DebuggerNonUserCode]
		public virtual void Remove (TEntity item) {
			// check item
			if (item == null) {
				throw new ArgumentNullException("item", "'item' argument is null.");
			}

			// check Unit of work.
			if (Context.UnitOfWorkCount <= 0) {
				throw new InvalidUnitOfWorkException();
			}

			// Attach object to context and delete this
			// this is valid only if T is a type in model
			Context.Attach(item);

			// delete object to IObjectSet for this type
			ItemSet.DeleteObject(item);
		}

		/// <summary>
		/// Attach entity to repository.
		/// Attach is similar to add but the internal state
		/// for this object is not  marked as 'Added, Modifed or Deleted', submit changes
		/// in Unit Of Work don't send anything to storage.
		/// </summary>
		/// <param name="item">Item to attach.</param>
		[DebuggerNonUserCode]
		public void Attach (TEntity item) {
			if (item == null) {
				throw new ArgumentNullException("item");
			}

			Context.Attach(item);
		}

		/// <summary>
		/// Sets modified entity into the repository. 
		/// When calling Commit() method in UnitOfWork 
		/// these changes will be saved into the storage.
		/// <remarks>
		/// Internally this method always calls Repository.Attach() and Context.SetChanges() 
		/// </remarks>
		/// </summary>
		/// <param name="item">Item with changes.</param>
		[DebuggerNonUserCode]
		public virtual void Modify (TEntity item) {
			// check arguments
			if (item == null) {
				throw new ArgumentNullException("item", "'item' argument is null.");
			}

			// check Unit of work.
			if (Context.UnitOfWorkCount <= 0) {
				throw new InvalidUnitOfWorkException();
			}

			// add object to IObjectSet for this type
			if (ItemSet is ObjectSet<TEntity>) {
				//((ObjectSet<TEntity>)ItemSet).ApplyChanges(item);
			} else {
				Context.SetChanges(item);
			}
		}

		/// <summary>
		/// Sets modified entities into the repository. 
		/// When calling Commit() method in UnitOfWork 
		/// these changes will be saved into the storage.
		/// </summary>
		/// <param name="items">Collection of items with changes.</param>
		[DebuggerNonUserCode]
		public virtual void Modify (ICollection<TEntity> items) {
			// check arguments
			if (items == null) {
				throw new ArgumentNullException("items", "'items' argument is null.");
			}

			// check Unit of work.
			if (Context.UnitOfWorkCount <= 0) {
				throw new InvalidUnitOfWorkException();
			}

			// for each element in collection apply changes
			foreach (var item in items.Where(item => item != null)) {
				Modify(item);
			}
		}

		/// <summary>
		/// Returns a single entitity based on specification query paramaters
		/// </summary>
		/// <remarks>only includes Filter and include Specficiation Types </remarks>
		/// <param name="specs">specification Parameters</param>
		/// <returns>entity object</returns>
		[DebuggerNonUserCode]
		public virtual TEntity Get (params ISpecification<TEntity>[] specs) {
			if (specs == null) {
				throw new ArgumentNullException("specs");
			}

			var query = ItemSet.AsQueryable();

			// Process Include specifications..);
			foreach (var specification in specs.OfType<IncludeSpecification<TEntity>>()) {
				query = query.Include(specification);
			}

			query = query.AsExpandable();

			// Process Filter specifications..
			foreach (var specification in specs.OfType<FilterSpecification<TEntity>>()) {
				query = query.Filter(specification);
			}

			return query.FirstOrDefault();
		}

		/// <summary>
		/// Get elements from repository that match the Filter, Sorting and Paging specifications provided.
		/// </summary>
		/// <param name="specs">The specification on how to filter, include, page and sort items in the repository. </param>
		/// <returns>List of items that match the filter specifications, ordered and paged.</returns>
		[DebuggerNonUserCode]
		public virtual IEnumerable<TEntity> GetElements (params ISpecification<TEntity>[] specs) {
			if (specs == null) {
				throw new ArgumentNullException("specs");
			}

			var query = ItemSet.AsQueryable();

			// Process Include specifications..);
			foreach (var specification in specs.OfType<IncludeSpecification<TEntity>>()) {
				query = query.Include(specification);
			}

			query = query.AsExpandable();

			// Process Filter specifications..
			foreach (var specification in specs.OfType<FilterSpecification<TEntity>>()) {
				query = query.Filter(specification);
			}

			// Process Sort specifications..
			var orderBySet = false;
			foreach (var specification in specs.OfType<SortSpecification<TEntity>>()) {
				query = orderBySet == false
									? query.OrderBy(specification)
									: ((IOrderedQueryable<TEntity>)query).ThenBy(specification);
				orderBySet = true;
			}

			// Process Paging specification.
			var pagingSet = false;
			foreach (var specification in specs.OfType<PagingSpecification<TEntity>>()) {
				if (!orderBySet) {
					// cannot set pagging without Order By.
					throw new Exception("Cannot process PagingSpecification without a SortSpecification.");
				}

				if (pagingSet) {
					// cannot re-set pagging.
					throw new Exception("Only one PagingSpecification is allowed.");
				}

				// Process Sort specifications..
				query = ((IOrderedQueryable<TEntity>)query).Paged(specification);
				pagingSet = true;
			}

			// Execute query.
			return query.AsEnumerable();
		}

		/// <summary>
		/// Get elements from repository that match the Filter, Sorting and Paging specifications provided.
		/// </summary>
		/// <param name="specs">The filter specifications to use to select items from repository.</param>
		/// <returns>Count of items that match the filter specifications..</returns>
		[DebuggerNonUserCode]
		public long GetElementCount (params ISpecification<TEntity>[] specs) {
			if (specs == null) {
				throw new ArgumentNullException("specs");
			}

			var query = ItemSet.AsExpandable();

			// Process Filter specifications..
			foreach (var specification in specs.OfType<FilterSpecification<TEntity>>()) {
				query = query.Filter(specification);
			}

			// Execute query.
			return query.LongCount();
		}

		#endregion

		#region IDisposable

		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		public void Dispose () {
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		/// <param name="disposing">Value indicating whether object is being disposed.</param>
		protected virtual void Dispose (bool disposing) {
			if (Status != RepositoryStatus.Disposed) {
				if (disposing) {
					if (Status == RepositoryStatus.Active) {
					}

					// Decrease repository counter.
					Context.RepositoryCount--;
				}
			}

			Status = RepositoryStatus.Disposed;
		}

		#endregion
	}
}