﻿using System;
using System.Linq;

namespace Framework.Data
{
	public static class EqualityComparer
	{
		// Helper method to determine if two byte arrays are the same value even if they are different object references
		public static bool BinaryEquals (object binaryValue1, object binaryValue2) {
			if (Object.ReferenceEquals(binaryValue1, binaryValue2)) {
				return true;
			}

			var array1 = binaryValue1 as byte[];
			var array2 = binaryValue2 as byte[];

			if (array1 != null && array2 != null) {
				if (array1.Length != array2.Length) {
					return false;
				}

				return !array1.Where((t, i) => t != array2[i]).Any();
			}

			return false;
		}
	}
}