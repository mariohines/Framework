﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Framework.Data.Collections
{
	public class TrackableCollection<T> : ObservableCollection<T>
	{
		protected override void ClearItems () {
			new List<T>(this).ForEach(t => Remove(t));
		}

		protected override void InsertItem (int index, T item) {
			if (!Contains(item)) {
				base.InsertItem(index, item);
			}
		}
	}
}