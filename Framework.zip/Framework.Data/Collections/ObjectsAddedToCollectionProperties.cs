﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Framework.Data.Collections
{
	[CollectionDataContract(Name = "ObjectsAddedToCollectionProperties",
				ItemName = "AddedObjectsForProperty", KeyName = "CollectionPropertyName", ValueName = "AddedObjects")]
	public class ObjectsAddedToCollectionProperties : Dictionary<string, ObjectList> { }
}