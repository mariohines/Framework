﻿using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using Framework.Extensions;
using Framework.Interfaces;

namespace Framework.Data
{
	/// <summary>Class to serialize other classes into Xml.</summary>
	/// <remarks>Best to inherit this class.</remarks>
	public class ClassSerializer : IXmlSerializer
	{
		private readonly XmlWriterSettings _settings;

		/// <summary>
		/// 
		/// </summary>
		public ClassSerializer() {
			_settings = new XmlWriterSettings {Encoding = Encoding.UTF8, Indent = true};
		}

		#region Implementation of IXmlSerializer

		/// <summary>Method to return the xml format of a particular type to a file.</summary>
		/// <param name="T">The type to serialize as xml.</param>
		/// <param name="filePath">The file path of where to dump the xml.</param>
		/// <remarks>If T is not passed in, it will assume the type as itself and 
		/// if filePath isn't passed in it will assume the it to be the location of the library.</remarks>
		public void ToXmlFile(Type T = null, string filePath = null) {
			var customObject = T ?? GetType();
			var customPath = string.IsNullOrEmpty(filePath)
			                 	? Assembly.GetAssembly(customObject).Location
			                 	: filePath;
			if (string.IsNullOrEmpty(customPath))
				throw new InvalidOperationException("An error has occured.");
			using (var writer = new FileStream(customPath, FileMode.Create)) {
				var serializer = new XmlSerializer(customObject);
				serializer.Serialize(writer, customObject);
				writer.Flush();
				writer.Close();
			}
		}

		#endregion

		#region Implementation of IXmlSerializer

		/// <summary>Method to return the xml format of <typeparamref name="TSource"/> to a string.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <param name="omitDeclaration">Either use declaration or not.</param>
		/// <returns>An xml string.</returns>
		public string ToXmlString<TSource>(TSource source, bool omitDeclaration = false) where TSource : class, new() {
			var output = new StringBuilder();
			_settings.OmitXmlDeclaration = omitDeclaration;
			using (var writer = XmlWriter.Create(output, _settings)) {
				var serializer = new XmlSerializer(typeof(TSource));
				serializer.Serialize(writer, source);
				writer.Flush();
			}
			return output.ToString();
		}

		/// <summary>Method to return the xml format of <typeparamref name="TSource"/> to a string using an xslt transform.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <param name="transform">The xslt used for the transformation.</param>
		/// <param name="omitDeclaration">Either use declaration or not.</param>
		/// <returns>An xml string.</returns>
		public string ToXmlStringWithTransform<TSource>(TSource source, string transform, bool omitDeclaration = false) where TSource : class, new() {
			throw new NotImplementedException();
		}

		/// <summary>Method to return the xml format of <typeparamref name="TSource"/> to a string using an xslt transform.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <param name="transform">The xslt used for the transformation.</param>
		/// <param name="omitDeclaration">Either use declaration or not.</param>
		/// <returns>An xml string.</returns>
		public string ToXmlStringWithTransform<TSource>(TSource source, XmlReader transform, bool omitDeclaration = false) where TSource : class, new() {
			throw new NotImplementedException();
		}

		/// <summary>Method to return the xml format of <typeparamref name="TSource"/> to a stream.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <returns>An generic stream containing xml.</returns>
		public Stream ToXmlStream<TSource>(TSource source) where TSource : class, new() {
			var stream = new MemoryStream();
			using (var writer = XmlWriter.Create(stream, _settings)) {
				var serializer = new XmlSerializer(typeof (TSource));
				serializer.Serialize(writer, source);
				writer.Flush();
			}
			return stream;
		}

		/// <summary>Method to return the xml format of <typeparamref name="TSource"/> to a stream using an xslt transform.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <param name="transform">The xslt used for the transform.</param>
		/// <returns>A generic stream containing xml.</returns>
		public Stream ToXmlStreamWithTransform<TSource>(TSource source, string transform) where TSource : class, new() {
			throw new NotImplementedException();
		}

		/// <summary>Method to return the xml format of <typeparamref name="TSource"/> to a stream using an xslt transform.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <param name="transform">The xslt used for the transform.</param>
		/// <returns>A generic stream containing xml.</returns>
		public Stream ToXmlStreamWithTransform<TSource>(TSource source, XmlReader transform) where TSource : class, new() {
			throw new NotImplementedException();
		}

		/// <summary>Method to return the xml format of a <typeparamref name="TSource"/> to a file.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <param name="filePath">The file path of where to dump the xml.</param>
		public void ToXmlFile<TSource>(TSource source, string filePath = null) where TSource : class, new() {
			var sourceType = typeof (TSource);
			var customPath = !filePath.HasValue()
												? Assembly.GetAssembly(sourceType).Location
												: filePath;
			if (string.IsNullOrEmpty(customPath)) {
				throw new InvalidOperationException("An error has occured.");
			}
			using (var writer = XmlWriter.Create(customPath, _settings)) {
				var serializer = new XmlSerializer(sourceType);
				serializer.Serialize(writer, source);
				writer.Flush();
			}
		}

		/// <summary>Method to return the xml format of a <typeparamref name="TSource"/> to a file using an xslt transform.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <param name="transform">The xslt used for the transform.</param>
		/// <param name="filePath">The file path of where to dump the xml.</param>
		public void ToXmlFileWithTransform<TSource>(TSource source, string transform, string filePath = null) where TSource : class, new() {
			throw new NotImplementedException();
		}

		/// <summary>Method to return the xml format of a <typeparamref name="TSource"/> to a file using an xslt transform.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The type to serialize as xml.</param>
		/// <param name="transform">The xslt used for the transform.</param>
		/// <param name="filePath">The file path of where to dump the xml.</param>
		public void ToXmlFileWithTransform<TSource>(TSource source, XmlReader transform, string filePath = null) where TSource : class, new() {
			throw new NotImplementedException();
		}

		#endregion
	}
}