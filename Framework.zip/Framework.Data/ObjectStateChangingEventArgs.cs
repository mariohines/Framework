﻿using System;
using Framework.Data.Enumerations;

namespace Framework.Data
{
	public class ObjectStateChangingEventArgs : EventArgs
	{
		public ObjectState NewState { get; set; }
	}
}