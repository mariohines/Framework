﻿using System;
using System.Linq.Expressions;
using Framework.Data.Enumerations;
using Framework.Data.Interfaces;

namespace Framework.Data.Specifications
{
	public class SortSpecification<TEntity>
		: ISpecification<TEntity>
		where TEntity : class, IObjectWithChangeTracker, new()
	{
		private readonly Expression<Func<TEntity, object>> _sortByExpression;
		private readonly string _sortColumnName;
		private readonly SortDirection _sortDirection;

		#region constructors

		public SortSpecification(string columnName, SortDirection sortDirection = SortDirection.Ascending) {
			_sortByExpression = null;
			_sortColumnName = columnName;
			_sortDirection = sortDirection;
		}

		public SortSpecification(Expression<Func<TEntity, object>> columnExpression,
		                         SortDirection sortDirection = SortDirection.Ascending) {
			_sortColumnName = null;
			_sortByExpression = columnExpression;
			_sortDirection = sortDirection;
		}

		#endregion

		public Expression<Func<TEntity, object>> SortByExpression {
			get { return _sortByExpression; }
		}

		public string SortColumnName {
			get { return _sortColumnName; }
		}

		public SortDirection SortDirection {
			get { return _sortDirection; }
		}
	}
}