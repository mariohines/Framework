﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IUnitOfWork.cs" >
// </copyright>
// <summary>
//   Contract for UnitOfWork pattern.
//   For more information see http://martinfowler.com/eaaCatalog/unitOfWork.html
//   and http://msdn.microsoft.com/en-us/magazine/dd882510.aspx
//   Unit Of Work is implemented in  ADO.NET Entity Framework
//   but this pattern is implemented to mantain Persistence Ignorance in the Business layer.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using Framework.Data.Enumerations;

namespace Framework.Data.Interfaces
{
	/// <summary>
	/// Contract for UnitOfWork pattern. 
	/// </summary>
	public interface IUnitOfWork
		: IDisposable
	{
		/// <summary>
		/// Gets or sets the Unit Of Work options that determine the behavior for Commits and Rollbacks.
		/// </summary>
		UnitOfWorkOptions DefaultOptions { get; set; }

		/// <summary>
		/// Gets or sets the current Status of this Unit Of Work.
		/// </summary>
		UnitOfWorkStatus Status { get; set; }

		/// <summary>
		/// Gets or sets the Audit information to use during the SaveChanges().
		/// </summary>
		AuditInfo AuditInfo { get; set; }

		/// <summary>
		/// Gets a value indicating whether the Unit of Work is at the Top Level.
		/// </summary>
		bool IsTopLevel { get; }

		/// <summary>
		/// Commit all pending changes to repository.
		/// </summary>
		/// <returns>A value indicating the result of the commit operation.</returns>
		int Commit();

		/// <summary>
		/// Rollback changes not already commited.
		/// </summary>
		void RollbackChanges();
	}
}