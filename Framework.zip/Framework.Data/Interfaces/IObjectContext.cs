﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IObjectContext.cs" >
// </copyright>
// <summary>
//   Defines the IObjectContext type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data.Objects;

namespace Framework.Data.Interfaces
{
	/// <summary>This is the basic contract for a Context.</summary>
	public interface IObjectContext
		: IDisposable
	{
		/// <summary>
		/// Gets the Unit of Work Counter.
		/// </summary>
		int UnitOfWorkCount { get; }

		/// <summary>
		/// Gets the UnitOfWork stack.
		/// </summary>
		Stack<IUnitOfWork> UnitOfWorkStack { get; }

		/// <summary>
		/// Gets or sets the Repository Counter.
		/// </summary>
		int RepositoryCount { get; set; }

		/// <summary>
		/// Apply changes made in item or related items in the object graph
		/// </summary>
		/// <typeparam name="TEntity">Type of item</typeparam>
		/// <param name="item">Item with changes</param>
		void SetChanges<TEntity>(TEntity item)
			where TEntity : class, IObjectWithChangeTracker, new();

		/// <summary>
		/// Persists all updates to the data source and resets change tracking in the object context.
		/// </summary>
		/// <returns>The number of objects in an Added, Modified, or Deleted state when SaveChanges was called.</returns>
		int SaveChanges();

		/// <summary>
		/// Attach object to container 
		/// </summary>
		/// <typeparam name="TEntity">Type of object to attach in container</typeparam>
		/// <param name="item">Item to attach in container</param>
		void Attach<TEntity>(TEntity item) where TEntity : class, IObjectWithChangeTracker, new();

		/// <summary>
		/// Create a object set for a type TEntity
		/// </summary>
		/// <typeparam name="TEntity">Type of elements in object set</typeparam>
		/// <returns>Object set of type {TEntity}</returns>
		IObjectSet<TEntity> CreateObjectSet<TEntity>() where TEntity : class, IObjectWithChangeTracker, new();
	}
}