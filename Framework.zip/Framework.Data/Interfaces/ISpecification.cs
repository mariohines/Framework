﻿namespace Framework.Data.Interfaces
{
	///<summary>
	///</summary>
	public interface ISpecification<TEntity>
		where TEntity : class, IObjectWithChangeTracker, new()
	{
	}
}