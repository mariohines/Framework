﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IRepository.cs" >
// </copyright>
// <summary>
//   Base interface for "Repository Pattern",
//   for more information about this pattern see http://martinfowler.com/eaaCatalog/repository.html
//   or http://blogs.msdn.com/adonet/archive/2009/06/16/using-repository-and-unit-of-work-patterns-with-entity-framework-4-0.aspx
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;

namespace Framework.Data.Interfaces
{
	/// <summary>Base interface for "Repository Pattern"</summary>
	/// <typeparam name="TEntity">An Entity type.</typeparam>
	public interface IObjectRepository<TEntity>
		: IDisposable
		where TEntity : class, IObjectWithChangeTracker, new()
	{
		#region Methods

		/// <summary>Add item to repository.</summary>
		/// <param name="item">Item to add to repository.</param>
		void Add(TEntity item);

		/// <summary>Delete an item from repository.</summary>
		/// <param name="item">Item to delete.</param>
		void Remove(TEntity item);

		/// <summary>
		/// Attach entity to repository.
		/// Attach is similar to add but the internal state
		/// for this object is not  marked as 'Added, Modifed or Deleted', submit changes
		/// in Unit Of Work don't send anything to storage.
		/// </summary>
		/// <param name="item">Item to attach.</param>
		void Attach(TEntity item);

		/// <summary>
		/// Sets modified entity into the repository. 
		/// When calling Commit() method in UnitOfWork 
		/// these changes will be saved into the storage.
		/// <remarks>
		/// Internally this method always calls Repository.Attach() and Context.SetChanges() 
		/// </remarks>
		/// </summary>
		/// <param name="item">Item with changes.</param>
		void Modify(TEntity item);

		/// <summary>
		/// Sets modified entities into the repository. 
		/// When calling Commit() method in UnitOfWork 
		/// these changes will be saved into the storage.
		/// </summary>
		/// <param name="items">Collection of items with changes.</param>
		void Modify(ICollection<TEntity> items);

		/// <summary>Returns a single entitity based on specification query paramaters</summary>
		/// <param name="specs">specification Parameters</param>
		/// <returns>entity object</returns>
		TEntity Get(params ISpecification<TEntity>[] specs);

		/// <summary>Get elements from repository that match the Filter, Sorting and Paging specifications.</summary>
		/// <returns>Elements from the repository that match the filer specification and ordered by sort specification.</returns>
		IEnumerable<TEntity> GetElements(params ISpecification<TEntity>[] specs);

		/// <summary>Get elements from repository that match the Filter, Sorting and Paging specifications.</summary>
		/// <returns>Elements from the repository that match the filer specification and ordered by sort specification.</returns>
		long GetElementCount(params ISpecification<TEntity>[] specs);

		#endregion
	}
}