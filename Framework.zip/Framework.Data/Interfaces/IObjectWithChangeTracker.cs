﻿namespace Framework.Data.Interfaces
{
	public interface IObjectWithChangeTracker
	{
		// Has all the change tracking information for the subgraph of a given object.
		ObjectChangeTracker ChangeTracker { get; }
	}
}