﻿using System;
using System.IO;
using System.Linq;
using Framework.Data.Enumerations;
using Framework.Data.Interfaces;

namespace Framework.Data.Extensions
{
	public static partial class Extensions
	{
		public static T MarkAsDeleted<T> (this T trackingItem) where T : IObjectWithChangeTracker {
			if (trackingItem == null) {
				throw new ArgumentNullException("trackingItem");
			}

			trackingItem.ChangeTracker.ChangeTrackingEnabled = true;
			trackingItem.ChangeTracker.State = ObjectState.Deleted;
			return trackingItem;
		}

		public static T MarkAsAdded<T> (this T trackingItem) where T : IObjectWithChangeTracker {
			if (trackingItem == null) {
				throw new ArgumentNullException("trackingItem");
			}

			trackingItem.ChangeTracker.ChangeTrackingEnabled = true;
			trackingItem.ChangeTracker.State = ObjectState.Added;
			return trackingItem;
		}

		public static T MarkAsModified<T> (this T trackingItem) where T : IObjectWithChangeTracker {
			if (trackingItem == null) {
				throw new ArgumentNullException("trackingItem");
			}

			trackingItem.ChangeTracker.ChangeTrackingEnabled = true;
			trackingItem.ChangeTracker.State = ObjectState.Modified;
			return trackingItem;
		}

		public static T MarkAsUnchanged<T> (this T trackingItem) where T : IObjectWithChangeTracker {
			if (trackingItem == null) {
				throw new ArgumentNullException("trackingItem");
			}

			trackingItem.ChangeTracker.ChangeTrackingEnabled = true;
			trackingItem.ChangeTracker.State = ObjectState.Unchanged;
			return trackingItem;
		}

		public static void StartTracking (this IObjectWithChangeTracker trackingItem) {
			if (trackingItem == null) {
				throw new ArgumentNullException("trackingItem");
			}

			trackingItem.ChangeTracker.ChangeTrackingEnabled = true;
		}

		public static void StopTracking (this IObjectWithChangeTracker trackingItem) {
			if (trackingItem == null) {
				throw new ArgumentNullException("trackingItem");
			}

			trackingItem.ChangeTracker.ChangeTrackingEnabled = false;
		}

		public static void AcceptChanges (this IObjectWithChangeTracker trackingItem) {
			if (trackingItem == null) {
				throw new ArgumentNullException("trackingItem");
			}

			trackingItem.ChangeTracker.AcceptChanges();
		}

		/// <summary></summary>
		/// <typeparam name="TSource"></typeparam>
		/// <param name="item"></param>
		/// <returns></returns>
		public static string ToXmlString<TSource> (this TSource item) where TSource : class, new() {
			var serializer = new ClassSerializer();
			return serializer.ToXmlString(item);
		}

		/// <summary></summary>
		/// <typeparam name="TSource"></typeparam>
		/// <param name="item"></param>
		/// <returns></returns>
		public static Stream ToXmlStream<TSource> (this TSource item) where TSource : class, new() {
			var serializer = new ClassSerializer();
			return serializer.ToXmlStream(item);
		}

		/// <summary></summary>
		/// <typeparam name="TSource"></typeparam>
		/// <param name="item"></param>
		/// <param name="filePath"></param>
		public static void ToXmlFile<TSource> (this TSource item, string filePath) where TSource : class, new() {
			var serializer = new ClassSerializer();
			serializer.ToXmlFile(item, filePath);
		}

		/// <summary></summary>
		/// <param name="info"></param>
		/// <returns></returns>
		public static string GetUsedSpaceAsString (this DirectoryInfo info) {
			long sizeInBytes = info.GetFiles("*", SearchOption.AllDirectories).Sum(f => f.Length);
			var unit = new UnitOfSpace((ulong)sizeInBytes);

			return unit.ToString();
		}

		/// <summary></summary>
		/// <param name="info"></param>
		/// <returns></returns>
		public static UnitOfSpace GetUsedSpace (this DirectoryInfo info) {
			long sizeInBytes = info.GetFiles("*", SearchOption.AllDirectories).Sum(f => f.Length);

			return new UnitOfSpace((ulong)sizeInBytes);
		}
	}
}
