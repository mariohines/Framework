﻿using System;

namespace Framework.Data.Enumerations
{
	#region EnumForObjectState
	[Flags]
	public enum ObjectState
	{
		Unchanged = 0x1,
		Added = 0x2,
		Modified = 0x4,
		Deleted = 0x8
	}
	#endregion

	#region ISpecification Enums

	public enum SortDirection
	{
		Ascending,
		Descending
	}

	#endregion

	#region Unit Of Work Enums

	/// <summary>
	/// Defines the Unit OF Work status
	/// </summary>
	public enum UnitOfWorkStatus
	{
		/// <summary>
		/// Unit of Work is active.
		/// </summary>
		Active,

		/// <summary>
		/// Unit of Work was commited successfully.
		/// </summary>
		Committed,

		/// <summary>
		/// Unit of Work was Rolled Back.
		/// </summary>
		RolledBack,

		/// <summary>
		/// Unit of Work was Dispossed.
		/// </summary>
		Disposed,
	}

	/// <summary>
	/// Specify the UnitOfWork options such as AutoCommit.
	/// </summary>
	[Flags]
	public enum UnitOfWorkOptions
	{
		/// <summary>
		/// An explicit Commit is needed before the end of the unit of work scope or changes are rolled back, 
		/// Any exceptions during the Unit of Work scope will Rollback changes.
		/// </summary>
		DefaultOptions = 0,

		/// <summary>
		/// Implicit Commit at the end of the Unit of Work Scope. 
		/// </summary>
		AutoCommit = 1,
	}

	#endregion

	/// <summary>
	/// Defines the posible status for a Repository object.
	/// </summary>
	public enum RepositoryStatus
	{
		Active,
		Disposed
	}
	/// <summary>
	/// Enumeration for the units of space for harddisk.
	/// </summary>
	public enum SizeUnit : ulong
	{
		/// <summary>Kilobyte</summary>
		Kb = 0x400,

		/// <summary>Megabyte</summary>
		Mb = 0x100000,

		///<summary>Gigabyte</summary>
		Gb = 0x40000000,

		///<summary>Terabyte</summary>
		Tb = 0x10000000000,

		///<summary>Exabyte</summary>
		Eb = 0x4000000000000
	}
}