﻿using Framework.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSubstitute;

namespace Framework.Tests.Builders
{
	[TestClass]
	public class XmlClassBuilderTests
	{
		[TestMethod]
		public void ToXmlStringTest() {
			
		}
	}
}
