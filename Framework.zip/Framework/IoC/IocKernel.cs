﻿using System;
using Ninject;

namespace Framework.IoC
{
	/// <summary>Single instance of Ninject Kernel.</summary>
	public sealed class IocKernel
	{
		#region Singleton Pattern
		private static readonly IKernel Kernel;
		private static volatile IKernel _instance;
		private static readonly Object SyncRoot = new Object();

		static IocKernel () {
			Kernel = new StandardKernel();
		}

		/// <summary>Static instance of the Ninject Kernel.</summary>
		public static IKernel Instance {
			get {
				if (_instance == null) {
					lock (SyncRoot) {
						if (_instance == null) {
							_instance = Kernel;
						}
					}
				}
				return _instance;
			}
		} 
		#endregion End Singleton Pattern
	}
}