﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LinqKit;

namespace Framework.Extensions
{
	public static partial class Extensions
	{
		#region Extension Methods for IEnumerable<string>

		/// <summary>Extension method to prefix all strings in an IEnumerable of type string.</summary>
		/// <param name="enumerable">The source IEnumerable of type string.</param>
		/// <param name="prefix">The string prefix.</param>
		/// <returns>An IEnumerable of type string.</returns>
		public static IEnumerable<string> PrefixAll (this IEnumerable<string> enumerable, string prefix) {
			var list = new List<string>();
			enumerable.ForEach(item => list.Add(string.Format("{0}{1}", prefix, item)));
			return list;
		}

		/// <summary>Extension method to suffix all strings in an IEnumerable of type string.</summary>
		/// <param name="enumerable">The source IEnumerable of type string.</param>
		/// <param name="suffix">The string suffix.</param>
		/// <returns>An IEnumerable of type string.</returns>
		public static IEnumerable<string> SuffixAll (this IEnumerable<string> enumerable, string suffix) {
			var list = new List<string>();
			enumerable.ForEach(item => list.Add(string.Format("{0}{1}", item, suffix)));
			return list;
		}

		/// <summary>Extension method to delimit the strings of an IEnumerable of type string into 1 string.</summary>
		/// <param name="enumerable">The source IEnumerable of type string.</param>
		/// <param name="delimeter">The delimiter to use. [Default is \r\n]</param>
		/// <returns>A string.</returns>
		public static string DelimitAllToString (this IEnumerable<string> enumerable, string delimeter = "\r\n") {
			return string.Join(delimeter, enumerable);
		}

		#endregion

		#region Extension Methods for class

		/// <summary>Extension method to convert an IEnumerable of type <typeparamref name="TSource"/> to a datatable.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="enumerable">The source IEnumerable of type <typeparamref name="TSource"/>.</param>
		/// <returns>A DataTable.</returns>
		public static DataTable ToDataTable<TSource> (this IEnumerable<TSource> enumerable) where TSource : class {
			DataTable table = GetDataTableOfType<TSource>();
			enumerable.ForEach(item => table.Rows.Add(item.ToDataRow(table)));
			return table;
		}

		/// <summary>Extension method to convert an IEnumerable of type <typeparamref name="TSource"/> to a byte array for CSV.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="enumerable">The source IEnumerable of type <typeparamref name="TSource"/>.</param>
		/// <returns>A byte array for CSV.</returns>
		public static byte[] ToCsv<TSource> (this IEnumerable<TSource> enumerable) where TSource : class {
			var table = enumerable.ToDataTable();
			var encoding = new ASCIIEncoding();
			var builder = new StringBuilder();
			var columnNames = table.Columns.SafeCast<DataColumn>().Select(column => column.ColumnName);

			builder.AppendLine(string.Join(",", columnNames));

			for (var i = 0; i < table.Rows.Count; i++) {
				var rowData = string.Join(",", table.Rows[i].ItemArray.SafeCast<string>());
				builder.AppendLine(rowData);
			}
			return encoding.GetBytes(builder.ToString());
		}

		#endregion End Extension Methods for class

		#region Extension Methods for Generic

		/// <summary>Extension method to execute an action across a generically typed collection.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="enumerable">The source IEnumerable of type <typeparamref name="TSource"/>.</param>
		/// <param name="action">An action to be performed on each item in the collection.</param>
		public static void ParallelExecute<TSource> (this IEnumerable<TSource> enumerable, Action<TSource> action) {
// ReSharper disable PossibleMultipleEnumeration
			enumerable.ThrowIfNull();
			action.ThrowIfNull();
			Parallel.ForEach(enumerable, Options, action);
// ReSharper restore PossibleMultipleEnumeration
		}

		/// <summary>Extension method to convert a null IEnumerable of type <typeparamref name="TSource"/> to an empty IEnumerable of type <typeparamref name="TSource"/>.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="enumerable">The source IEnumerable of type <typeparamref name="TSource"/>.</param>
		/// <returns>An IEnumerable of type <typeparamref name="TSource"/>.</returns>
		public static IEnumerable<TSource> EmptyIfNull<TSource> (this IEnumerable<TSource> enumerable) {
			return enumerable ?? new List<TSource>().AsEnumerable();
		}

		/// <summary>Extension method to safely cast an IEnumerable to an IEnumerable of type <typeparamref name="TSource"/>.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="enumerable">The source IEnumerable of type <typeparamref name="TSource"/>.</param>
		/// <returns>An IEnumerable of type <typeparamref name="TSource"/>.</returns>
		public static IEnumerable<TSource> SafeCast<TSource> (this IEnumerable enumerable) {
			return (from object item in enumerable select (TSource)Convert.ChangeType(item, typeof(TSource)));
		}

		/// <summary></summary>
		/// <typeparam name="TSource"></typeparam>
		/// <param name="enumerable"></param>
		/// <returns></returns>
		public static bool IsEmptyOrNull<TSource> (this IEnumerable<TSource> enumerable) {
			return enumerable == null || !enumerable.Any();
		}

		#endregion End Extension Methods for Generic
	}
}
