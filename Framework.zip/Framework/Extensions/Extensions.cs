﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Framework.Extensions
{
	/// <summary>Collection of commonly used extensions.</summary>
	public static partial class Extensions
	{
		private static readonly ParallelOptions Options;

		static Extensions() {
			Options = new ParallelOptions {MaxDegreeOfParallelism = (int) (Environment.ProcessorCount*1.5)};
		}

		/// <summary></summary>
		/// <param name="element"></param>
		/// <param name="elementName"></param>
		/// <returns></returns>
		public static XElement EmptyIfNull(this XElement element, string elementName) {
			return element ?? new XElement(elementName) {Value = string.Empty};
		}

		/// <summary></summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The input source.</param>
		/// <param name="dataTable">The parent DataTable. [Optional]</param>
		/// <returns></returns>
		public static DataRow ToDataRow<TSource>(this TSource source, DataTable dataTable = null) where TSource : class {
			DataRow row = (dataTable ?? GetDataTableOfType<TSource>()).NewRow();
			foreach (
				PropertyInfo property in typeof (TSource).GetProperties().Where(property => IsValidType(property.PropertyType))) {
				row[property.Name] = property.GetValue(source, null);
			}

			return row;
		}

		/// <summary>Extension method on a DataTable to return a list of DataRows.</summary>
		/// <param name="table">The source DataTable.</param>
		/// <returns>An IEnumerable of type DataRow.</returns>
		public static IEnumerable<DataRow> ToRowList(this DataTable table) {
			return table.Rows.SafeCast<DataRow>();
		}

		/// <summary>Extension method on a class to validate if the class is null.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The input source.</param>
		/// <returns>A boolean value.</returns>
		public static bool IsNull<TSource>(this TSource source) where TSource : class {
			return (source is string) ? !(source as string).HasValue() : source == null;
		}

		/// <summary>Extension method to throw an exception if the source is null.</summary>
		/// <typeparam name="TSource">The source type.</typeparam>
		/// <param name="source">The input source.</param>
		public static void ThrowIfNull<TSource> (this TSource source) where TSource : class {
			if (source.IsNull()) {
				throw new ArgumentNullException("source");
			}
		}

		#region Private Methods

		/// <summary></summary>
		/// <typeparam name="T"></typeparam>
		/// <returns></returns>
		private static DataTable GetDataTableOfType<T>() where T : class {
			var table = new DataTable(string.Format("{0}{1}", typeof (T).Name, "DataTable"));
			foreach (PropertyInfo property in typeof (T).GetProperties().Where(property => IsValidType(property.PropertyType))) {
				table.Columns.Add(property.Name, property.PropertyType);
			}

			return table;
		}

		private static bool IsValidType(Type info) {
			var o = (info.IsValueType || info.IsAnsiClass) && !info.IsGenericType && !info.IsArray;
			return o;
		}

		#endregion End Private Methods
	}
}