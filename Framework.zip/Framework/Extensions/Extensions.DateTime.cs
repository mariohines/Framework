﻿using System;
using Framework.Enumerations;

namespace Framework.Extensions
{
	public static partial class Extensions
	{
		#region DateTime Extensions

		/// <summary>Extension method to give true/false on the date being a weekend.</summary>
		/// <param name="dateTime">The source DateTime.</param>
		/// <returns>A boolean value.</returns>
		public static bool IsWeekend (this DateTime dateTime) {
			var result = dateTime.DayOfWeek == DayOfWeek.Saturday || dateTime.DayOfWeek == DayOfWeek.Sunday;
			return result;
		}

		/// <summary>Extension method to return the first day of a passed in date.</summary>
		/// <param name="dateTime">The source DateTime.</param>
		/// <returns>A DateTime of the first day.</returns>
		public static DateTime FirstDay (this DateTime dateTime) {
			return new DateTime(dateTime.Year, dateTime.Month, 1);
		}

		/// <summary>Extension method to return the last day of a passed in date.</summary>
		/// <param name="dateTime">The source DateTime.</param>
		/// <returns>A DateTime of the last day.</returns>
		public static DateTime LastDay (this DateTime dateTime) {
			int daysInMonth = DateTime.DaysInMonth(dateTime.Year, dateTime.Month);
			return new DateTime(dateTime.Year, dateTime.Month, daysInMonth);
		}

		/// <summary>Gets an enumerated Months value for a datetime.</summary>
		/// <param name="dateTime">The source DateTime.</param>
		/// <returns>A Months enumeration value.</returns>
		public static Months GetMonth (this DateTime dateTime) {
			return (Months)dateTime.Month;
		}

		/// <summary></summary>
		/// <param name="dateTime"></param>
		/// <returns></returns>
		public static ZodiacSigns ResolveZodiac (this DateTime dateTime) {
			ZodiacSigns signs;

			switch ((Months)dateTime.Month) {
				case Months.January:
					signs = dateTime.Day <= 19 ? ZodiacSigns.Capricorn : ZodiacSigns.Aquarius;
					break;
				case Months.February:
					signs = dateTime.Day <= 18 ? ZodiacSigns.Aquarius : ZodiacSigns.Pisces;
					break;
				case Months.March:
					signs = dateTime.Day <= 20 ? ZodiacSigns.Pisces : ZodiacSigns.Aries;
					break;
				case Months.April:
					signs = dateTime.Day <= 19 ? ZodiacSigns.Aries : ZodiacSigns.Taurus;
					break;
				case Months.May:
					signs = dateTime.Day <= 20 ? ZodiacSigns.Taurus : ZodiacSigns.Gemini;
					break;
				case Months.June:
					signs = dateTime.Day <= 20 ? ZodiacSigns.Gemini : ZodiacSigns.Cancer;
					break;
				case Months.July:
					signs = dateTime.Day <= 22 ? ZodiacSigns.Cancer : ZodiacSigns.Leo;
					break;
				case Months.August:
					signs = dateTime.Day <= 22 ? ZodiacSigns.Leo : ZodiacSigns.Virgo;
					break;
				case Months.September:
					signs = dateTime.Day <= 22 ? ZodiacSigns.Virgo : ZodiacSigns.Libra;
					break;
				case Months.October:
					signs = dateTime.Day <= 22 ? ZodiacSigns.Libra : ZodiacSigns.Scorpio;
					break;
				case Months.November:
					signs = dateTime.Day <= 21 ? ZodiacSigns.Scorpio : ZodiacSigns.Sagittarius;
					break;
				case Months.December:
					signs = dateTime.Day <= 21 ? ZodiacSigns.Sagittarius : ZodiacSigns.Capricorn;
					break;
				default:
					throw new ArgumentOutOfRangeException();
			}
			return signs;
		}

		#endregion End DateTime Extensions
	}
}