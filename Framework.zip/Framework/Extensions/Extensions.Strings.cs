﻿using System.Globalization;
using System.Linq;

namespace Framework.Extensions
{
	public static partial class Extensions
	{
		/// <summary>Extension method to properly case a string.</summary>
		/// <param name="s">The source string.</param>
		/// <returns>The properly cased string.</returns>
		public static string ToProperCase(this string s) {
			CultureInfo culture = CultureInfo.CurrentCulture;
			return culture.TextInfo.ToTitleCase(s.ToLower());
		}

		/// <summary>Extension method to verify if a string has a value.</summary>
		/// <param name="s">The source string.</param>
		/// <returns>A boolean value.</returns>
		public static bool HasValue(this string s) {
			return !string.IsNullOrWhiteSpace(s);
		}

		/// <summary>Extension method to do a mass replace of old strings with a new string.</summary>
		/// <param name="s">The source string.</param>
		/// <param name="oldValues">The string array of old values.</param>
		/// <param name="newValue">The replacement string.</param>
		/// <returns>The formatted string.</returns>
		public static string ReplaceAll(this string s, string[] oldValues, string newValue) {
			return oldValues.Aggregate(s, (current, oldValue) => current.Replace(oldValue, newValue));
		}

		/// <summary>Extension method to do a mass replace of old characters with a new character.</summary>
		/// <param name="s">The source string.</param>
		/// <param name="oldValues">The character array of old values.</param>
		/// <param name="newValue">The replacement character.</param>
		/// <returns>The formatted string.</returns>
		public static string ReplaceAll(this string s, char[] oldValues, char newValue) {
			return oldValues.Aggregate(s, (current, oldValue) => current.Replace(oldValue, newValue));
		}
	}
}