﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Dynamic;
using System.Linq;

namespace Framework.Collections
{
	/// <summary>A dynamic class for setting up dynamic configuration collections.</summary>
	public class DynamicCollection : DynamicObject
	{
		private readonly Dictionary<string, object> _collection;

		/// <summary></summary>
		public DynamicCollection ()
			: this(new Dictionary<string, object>()) {

		}

		/// <summary>Parameterized constructor for NameValueCollection.</summary>
		/// <param name="collection">A NameValueCollection.</param>
		public DynamicCollection(NameValueCollection collection) {
			var dictionary = collection.AllKeys.ToDictionary(k => k, v => (object) collection[v]);
			_collection = new Dictionary<string, object>(dictionary);
		}

		/// <summary>Parameterized constructor for IDictionary.</summary>
		/// <param name="dictionary">An IDictionary collection.</param>
		public DynamicCollection(IDictionary<string, object> dictionary) {
			_collection = new Dictionary<string, object>(dictionary);
		}

		/// <summary>Parameterized constructor for IDataReader.</summary>
		/// <param name="reader">An IDataReader.</param>
		/// <remarks>Close reader after this is used and/or called.</remarks>
		public DynamicCollection(IDataReader reader) {
			_collection = new Dictionary<string, object>();
			var fieldCount = reader.FieldCount;
			var row = 0;
			while (reader.Read()) {
				++row;
				var rowstring = string.Format("_Row{0}", row);
				for (var i = 0; i < fieldCount; i++) {
					var name = reader.GetName(i);
					_collection[name + rowstring] = reader[name];
				}
			}
		}

		public override bool TryGetMember(GetMemberBinder binder, out object result) {
			var name = binder.Name;
			return _collection.TryGetValue(name, out result);
		}

		public override bool TrySetMember(SetMemberBinder binder, object value) {
			_collection[binder.Name] = value;
			return true;
		}

		public override IEnumerable<string> GetDynamicMemberNames() {
			return _collection.Keys;
		}

		/// <summary></summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="key"></param>
		/// <param name="value"></param>
		public void AddProperty<T>(string key, T value = default(T)) {
			_collection[key] = value;
		}

		/// <summary></summary>
		/// <param name="typeName"></param>
		/// <param name="key"></param>
		/// <param name="value"></param>
		public void AddProperty(string typeName, string key, object value = null) {
			var type = Type.GetType(typeName);
			if (type == null) return;
			_collection[key] = Convert.ChangeType(value, type);
		}
	}
}