﻿using System;

namespace Framework.Interfaces
{
	public interface INotifyComplexPropertyChanging
	{
		event EventHandler ComplexPropertyChanging;
	}
}