﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyProduct("Framework.Web")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("c37dbb60-590d-4155-87d0-9c80a5c54084")]