﻿using System.Configuration;

namespace Framework.Web.Configuration
{
	/// <summary></summary>
	public sealed class XmlRoutingConfiguration : ConfigurationSection
	{
		#region Fields
		private static readonly ConfigurationProperty RouteFile;
		private static readonly ConfigurationProperty IsCached;
		private static readonly ConfigurationPropertyCollection Property; 
		#endregion

		#region Properties
		/// <summary></summary>
		protected override ConfigurationPropertyCollection Properties {
			get { return Property; }
		}

		/// <summary></summary>
		public string RouteFileLocation {
			get { return (string) this["routingFile"]; }
			set { this["routingFile"] = value; }
		}

		/// <summary></summary>
		public bool IsRoutingCached {
			get { return (bool) this["isCached"]; }
			set { this["isCached"] = value; }
		}

		#endregion

		static XmlRoutingConfiguration() {
			RouteFile = new ConfigurationProperty("routeFile", typeof (string), @"App_Data\routes.xml",
			                                      ConfigurationPropertyOptions.None);
			IsCached = new ConfigurationProperty("isCached", typeof(bool), false, ConfigurationPropertyOptions.IsRequired);
			Property = new ConfigurationPropertyCollection {RouteFile, IsCached};
		}
	}
}
