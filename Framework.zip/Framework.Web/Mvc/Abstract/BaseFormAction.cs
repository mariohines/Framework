﻿using System.Web.Mvc;

namespace Framework.Web.Mvc.Abstract
{
	/// <summary></summary>
	/// <typeparam name="TModel"></typeparam>
	public abstract class BaseFormAction<TModel> : ActionResult
	{
		#region Public Members
		/// <summary></summary>
		public TModel Model { get; private set; }

		/// <summary></summary>
		public ViewResult Failure { get; private set; }

		/// <summary></summary>
		public ActionResult Success { get; private set; } 
		#endregion End Public Members

		protected BaseFormAction (TModel model, ActionResult success, ViewResult failure) {
			Model = model;
			Success = success;
			Failure = failure;
		}
	} 
}