﻿using System.Web.Mvc;
using Framework.Collections;

namespace Framework.Web.Mvc.Abstract
{
	/// <summary></summary>
	public abstract class BaseMvcViewPage : WebViewPage
	{
		private dynamic _tempBag;

		/// <summary>Holds temporary data dynmaically.</summary>
		public dynamic TempBag {
			get { return _tempBag ?? (_tempBag = new DynamicCollection(TempData)); }
		}
	}

	/// <summary></summary>
	/// <typeparam name="TModel"></typeparam>
	public abstract class BaseMvcViewPage<TModel> : BaseMvcViewPage
	{
		private ViewDataDictionary<TModel> _viewData;
		public new AjaxHelper<TModel> Ajax { get; set; }
		public new HtmlHelper<TModel> Html { get; set; }

		public new TModel Model {
			get { return ViewData.Model; }
		}

		public new ViewDataDictionary<TModel> ViewData {
			get { return _viewData ?? (_viewData = new ViewDataDictionary<TModel>()); }
			set { SetViewData(value); }
		}

		public override void InitHelpers () {
			base.InitHelpers();
			Ajax = new AjaxHelper<TModel>(ViewContext, this);
			Html = new HtmlHelper<TModel>(ViewContext, this);
		}

		protected override void SetViewData (ViewDataDictionary viewData) {
			_viewData = new ViewDataDictionary<TModel>(viewData);
			base.SetViewData(viewData);
		}
	}
}