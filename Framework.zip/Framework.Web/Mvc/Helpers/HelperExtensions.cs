﻿using System.Web.Mvc;
using Framework.Web.Builders;

namespace Framework.Web.Mvc.Helpers
{
	public static class HelperExtensions
	{
		/// <summary></summary>
		/// <param name="html"></param>
		/// <param name="tagName"></param>
		/// <returns></returns>
		public static FluentTagBuilder Fluent(this HtmlHelper html, string tagName) {
			return new FluentTagBuilder(tagName);
		}

		/// <summary></summary>
		/// <typeparam name="TModel"></typeparam>
		/// <param name="html"></param>
		/// <param name="tagName"></param>
		/// <returns></returns>
		public static FluentTagBuilder Fluent<TModel>(this HtmlHelper<TModel> html, string tagName) {
			return new FluentTagBuilder(tagName);
		}
	}
}