﻿using System.Collections.Generic;
using System.Web.Routing;
using System.Xml.Serialization;
using Framework.Extensions;

namespace Framework.Web.Routing.Models
{
	/// <summary></summary>
	[XmlRoot("ignore")]
	[XmlType("ignore")]
	public class XmlIgnoreRoute
	{
		/// <summary></summary>
		[XmlElement("url")]
		public string Url { get; set; }

		/// <summary></summary>
		[XmlElement("constraints")]
		public XmlRouteConstraint Constraints { get; set; }

		/// <summary></summary>
		/// <param name="ignoreRoute"></param>
		/// <returns></returns>
		public static explicit operator RouteBase(XmlIgnoreRoute ignoreRoute) {
			var route = new LowercaseRoute(ignoreRoute.Url, new StopRoutingHandler());
			if (!ignoreRoute.Constraints.IsNull()) {
				route.Constraints = new RouteValueDictionary(ignoreRoute.Constraints.ConstraintDictionary);
			}
			return route;
		}
	}
}
