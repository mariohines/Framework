﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace Framework.Web.Routing.Models
{
	/// <summary></summary>
	[XmlRoot("routes")]
	public class XmlRoutes
	{
		/// <summary></summary>
		[XmlElement("ignore")]
		public List<XmlIgnoreRoute> IgnoredRoutes { get; set; }

		/// <summary></summary>
		[XmlElement("route")]
		public List<XmlRoute> Routes { get; set; }
	}
}
