﻿using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Routing;
using System.Xml.Serialization;
using Framework.Extensions;

namespace Framework.Web.Routing.Models
{
	/// <summary></summary>
	[XmlRoot("route")]
	[XmlType("route")]
	public class XmlRoute
	{
		/// <summary></summary>
		[XmlElement("name")]
		public string Name { get; set; }

		/// <summary></summary>
		[XmlElement("url")]
		public string Url { get; set; }

		/// <summary></summary>
		[XmlElement("defaults")]
		public XmlRouteDefault Defaults { get; set; }

		/// <summary></summary>
		[XmlElement("constraints")]
		public XmlRouteConstraint Constraints { get; set; }

		/// <summary></summary>
		[XmlElement("namespaces")]
		public string Namespaces { get; set; }

		/// <summary></summary>
		/// <param name="xmlRoute"></param>
		/// <returns></returns>
		public static explicit operator RouteBase(XmlRoute xmlRoute) {
			var route = new LowercaseRoute(xmlRoute.Url, new MvcRouteHandler());
			if (!xmlRoute.Defaults.IsNull()) {
				route.Defaults = new RouteValueDictionary(xmlRoute.Defaults.DefaultDictionary);
			}
			if (!xmlRoute.Constraints.IsNull()) {
				route.Constraints = new RouteValueDictionary(xmlRoute.Constraints.ConstraintDictionary);
			}
			if (xmlRoute.Namespaces.HasValue()) {
				route.DataTokens =
					new RouteValueDictionary(new Dictionary<string, object> {{"Namespaces", xmlRoute.Namespaces.Split(',')}}
						);
			}
			return route;
		}
	}
}
