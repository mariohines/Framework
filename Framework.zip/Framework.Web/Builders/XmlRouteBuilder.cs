﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Web.Mvc;
using System.Web.Routing;
using System.Xml;
using System.Xml.Serialization;
using Framework.Web.Configuration;
using Framework.Web.Routing;
using Framework.Web.Routing.Models;
using LinqKit;

namespace Framework.Web.Builders
{
	/// <summary></summary>
	public sealed class XmlRouteBuilder
	{
		/// <summary>Method to build the routing table via an xml file.</summary>
		/// <param name="routeCollection">The collection of http routes.</param>
		public static void LoadRoutes(RouteCollection routeCollection) {
			var routeSection = ConfigurationManager.GetSection("routingConfiguration") as XmlRoutingConfiguration;
			if(routeSection == null) {
				throw new ApplicationException("No routingConfiguration section exists in the config file.");
			}

			// Clears the routing collection.
			routeCollection.Clear();

			var path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, routeSection.RouteFileLocation);
			BuildRoutes(path, routeCollection);
		}
		
		private static void BuildRoutes(string path, RouteCollection routeCollection) {
			XmlRoutes routes;
			using (var reader = XmlReader.Create(new FileStream(path, FileMode.Open))) {
				var serializer = new XmlSerializer(typeof (XmlRoutes));
				routes = serializer.Deserialize(reader) as XmlRoutes;
			}

			if (routes == null) {
				throw new ApplicationException("There was an error deserializing the routing file. Please verify that it follows the correct schema.");
			}

			// Handle all the ignored routes first.
			BuildIgnoreRoutes(routes.IgnoredRoutes, routeCollection);

			routes.Routes.ForEach
				(r => {
				 	var route = new LowercaseRoute(r.Url, new RouteValueDictionary(r.Defaults.DefaultDictionary),
				 	                               new RouteValueDictionary(r.Constraints.ConstraintDictionary),
				 	                               new MvcRouteHandler());
				 	routeCollection.Add(route);
				 }
				);
		}

		private static void BuildIgnoreRoutes(IEnumerable<XmlIgnoreRoute> ignoredRoutes, RouteCollection routeCollection) {
			ignoredRoutes.ForEach
				(r => {
				 	var route = new LowercaseRoute(r.Url, new StopRoutingHandler())
				 	            {Constraints = new RouteValueDictionary(r.Constraints.ConstraintDictionary)};
				 	routeCollection.Add(route);
				 }
				);
		}
	}
}