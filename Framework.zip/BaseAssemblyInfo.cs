﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Framework")]
[assembly: AssemblyDescription("A collection of libraries for personal use by Mario Hines.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Gigatech Inc.")]
[assembly: AssemblyCopyright("Copyright © Gigatech Inc. 2012")]
[assembly: AssemblyTrademark("None")]
[assembly: AssemblyCulture("en-us")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("3.0.0.0")]
[assembly: AssemblyFileVersion("3.0.0.0")]